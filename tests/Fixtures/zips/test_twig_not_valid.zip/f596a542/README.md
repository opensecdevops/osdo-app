# Laravel + InertiaJS CI Pipeline para GitLab

Este paquete proporciona una solución completa de Integración Continua (CI) para proyectos Laravel con InertiaJS en GitLab. Diseñado para maximizar la eficiencia y seguridad, este pipeline incluye una serie de bloques predefinidos que cubren desde la preparación inicial hasta la publicación y firma de imágenes Docker.

## Bloques Disponibles en el Pipeline

### 1. Preparación

- **Descripción**: Configura el entorno necesario para ejecutar el pipeline, incluyendo la instalación de dependencias y la configuración inicial.
- **Uso**: Ideal para iniciar el proceso de CI con todas las herramientas y dependencias requeridas.

### 2. SBOM (Software Bill of Materials)

- **Descripción**: Genera y analiza el SBOM para identificar todas las dependencias y sus versiones en el proyecto.
- **Uso**: Fundamental para la gestión de dependencias y la seguridad del software.

### 3. PHPUnit

- **Descripción**: Ejecuta pruebas PHPUnit para garantizar la calidad y funcionalidad del código.
- **Uso**: Esencial para la validación y aseguramiento de la calidad del código PHP.

### 4. Detección de Contraseñas

- **Descripción**: Busca posibles filtraciones de contraseñas en el repositorio del proyecto.
- **Uso**: Clave para mantener la seguridad y la integridad del código fuente.

### 5. Análisis Estático con SonarQube

- **Descripción**: Utiliza SonarQube para realizar un análisis estático del código, identificando posibles errores y vulnerabilidades.
- **Uso**: Mejora la calidad del código detectando problemas antes de que lleguen a producción.

### 6. Análisis de Dockerfile

- **Descripción**: Analiza el Dockerfile en busca de posibles problemas o malas prácticas.
- **Uso**: Asegura que los Dockerfiles sigan las mejores prácticas y estén libres de problemas comunes.

### 7. Construcción de Imágenes

- **Descripción**: Construye imágenes Docker basadas en el proyecto Laravel + InertiaJS.
- **Uso**: Permite generar imágenes Docker listas para ser desplegadas en cualquier entorno compatible.

### 8. Análisis de Imágenes

- **Descripción**: Realiza un análisis en profundidad de las imágenes Docker generadas para detectar vulnerabilidades.
- **Uso**: Garantiza que las imágenes Docker sean seguras antes de su despliegue.

### 9. Publicación de Imágenes

- **Descripción**: Publica las imágenes Docker en un registro de contenedores.
- **Uso**: Facilita el despliegue y distribución de las imágenes Docker a través de registros.

### 10. Firma de las Imágenes

- **Descripción**: Firma digitalmente las imágenes Docker para verificar su autenticidad.
- **Uso**: Aumenta la seguridad y la confianza en las imágenes Docker distribuidas.


---------------------------------

# Laravel + InertiaJS CI Pipeline for GitLab

This package provides a complete Continuous Integration (CI) solution for Laravel projects with InertiaJS on GitLab. Designed to maximize efficiency and security, this pipeline includes a series of predefined blocks covering everything from initial preparation to Docker image publishing and signing.

## Available Blocks in the Pipeline

### 1. Preparation

- **Description**: Sets up the necessary environment to run the pipeline, including dependency installation and initial configuration.
- **Usage**: Ideal for starting the CI process with all the required tools and dependencies.

### 2. SBOM (Software Bill of Materials)

- **Description**: Generates and analyzes the SBOM to identify all dependencies and their versions in the project.
- **Usage**: Essential for dependency management and software security.

### 3. PHPUnit

- **Description**: Runs PHPUnit tests to ensure the quality and functionality of the code.
- **Usage**: Essential for PHP code quality validation and assurance.

### 4. Password Detection

- **Description**: Searches for potential password leaks in the project repository.
- **Usage**: Key to maintaining the security and integrity of the source code.

### 5. Static Analysis with SonarQube

- **Description**: Uses SonarQube for static code analysis, identifying potential errors and vulnerabilities.
- **Usage**: Improves code quality by detecting issues before they reach production.

### 6. Dockerfile Analysis

- **Description**: Analyzes the Dockerfile for potential problems or bad practices.
- **Usage**: Ensures that Dockerfiles follow best practices and are free of common issues.

### 7. Image Building

- **Description**: Builds Docker images based on the Laravel + InertiaJS project.
- **Usage**: Allows for the generation of Docker images ready for deployment in any compatible environment.

### 8. Image Analysis

- **Description**: Performs an in-depth analysis of the generated Docker images to detect vulnerabilities.
- **Usage**: Ensures that Docker images are secure before deployment.

### 9. Image Publishing

- **Description**: Publishes Docker images to a container registry.
- **Usage**: Facilitates the deployment and distribution of Docker images through registries.

### 10. Image Signing

- **Description**: Digitally signs Docker images to verify their authenticity.
- **Usage**: Increases security and trust in the distributed Docker images.